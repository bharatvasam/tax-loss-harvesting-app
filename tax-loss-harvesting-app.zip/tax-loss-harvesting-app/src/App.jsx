import React, { useEffect, useState } from 'react';
import PreHarvestCard from './components/PreHarvestCard';
import PostHarvestCard from './components/PostHarvestCard';
import HoldingsTable from './components/HoldingsTable';
import { fetchCapitalGains, fetchHoldings } from './data/mockApi';

export default function App() {
  const [originalGains, setOriginalGains] = useState(null);
  const [selectedGains, setSelectedGains] = useState(null);
  const [holdings, setHoldings] = useState([]);
  const [selected, setSelected] = useState([]);

  useEffect(() => {
    fetchCapitalGains().then(data => {
      setOriginalGains(data);
      setSelectedGains(JSON.parse(JSON.stringify(data)));
    });
    fetchHoldings().then(data => setHoldings(data));
  }, []);

  const handleSelectionChange = (selectedHoldings) => {
    setSelected(selectedHoldings);
    if (!originalGains) return;

    const updated = JSON.parse(JSON.stringify(originalGains));
    selectedHoldings.forEach(h => {
      if (h.stcg.gain > 0) updated.stcg.profits += h.stcg.gain;
      else updated.stcg.losses += Math.abs(h.stcg.gain);

      if (h.ltcg.gain > 0) updated.ltcg.profits += h.ltcg.gain;
      else updated.ltcg.losses += Math.abs(h.ltcg.gain);
    });
    setSelectedGains(updated);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <PreHarvestCard gains={originalGains} />
        <PostHarvestCard gains={selectedGains} originalGains={originalGains} />
      </div>
      <HoldingsTable holdings={holdings} onSelectionChange={handleSelectionChange} />
    </div>
  );
}