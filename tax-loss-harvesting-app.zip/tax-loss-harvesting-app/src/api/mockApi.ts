export const fetchCapitalGains = async () => {
  return new Promise((resolve) =>
    setTimeout(
      () =>
        resolve({
          stcg: { profits: 100, losses: 500 },
          ltcg: { profits: 1200, losses: 100 },
        }),
      500
    )
  );
};

export const fetchHoldings = async () => {
  return new Promise((resolve) =>
    setTimeout(
      () =>
        resolve([
          {
            id: '1',
            coin: 'eth',
            coinName: 'Ethereum',
            logo: 'https://cryptologos.cc/logos/ethereum-eth-logo.png',
            totalHoldings: 2,
            averageBuyPrice: 1500,
            currentPrice: 1800,
            stcg: { gain: 500, balance: 2 },
            ltcg: { gain: -1000, balance: 1 },
          },
          {
            id: '2',
            coin: 'btc',
            coinName: 'Bitcoin',
            logo: 'https://cryptologos.cc/logos/bitcoin-btc-logo.png',
            totalHoldings: 1,
            averageBuyPrice: 30000,
            currentPrice: 35000,
            stcg: { gain: 200, balance: 1 },
            ltcg: { gain: 500, balance: 1 },
          },
        ]),
      500
    )
  );
};