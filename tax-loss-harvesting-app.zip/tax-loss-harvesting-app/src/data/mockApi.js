export const fetchCapitalGains = () => Promise.resolve({
  stcg: { profits: 100, losses: 500 },
  ltcg: { profits: 1200, losses: 100 },
});

export const fetchHoldings = () => Promise.resolve([
  {
    coin: 'ETH',
    coinName: 'Ethereum',
    logo: 'https://cryptologos.cc/logos/ethereum-eth-logo.png',
    totalHoldings: 2,
    averageBuyPrice: 1000,
    currentPrice: 900,
    stcg: { gain: 500, balance: 1 },
    ltcg: { gain: -1000, balance: 1 },
  },
  {
    coin: 'BTC',
    coinName: 'Bitcoin',
    logo: 'https://cryptologos.cc/logos/bitcoin-btc-logo.png',
    totalHoldings: 1,
    averageBuyPrice: 25000,
    currentPrice: 30000,
    stcg: { gain: 1000, balance: 1 },
    ltcg: { gain: 500, balance: 0 },
  }
]);