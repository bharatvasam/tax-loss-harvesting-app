import React from 'react';

export default function PostHarvestCard({ gains, originalGains }) {
  if (!gains || !originalGains) return null;

  const netST = gains.stcg.profits - gains.stcg.losses;
  const netLT = gains.ltcg.profits - gains.ltcg.losses;
  const total = netST + netLT;

  const originalNet = (originalGains.stcg.profits - originalGains.stcg.losses) +
                      (originalGains.ltcg.profits - originalGains.ltcg.losses);
  const savings = originalNet - total;

  return (
    <div className="bg-blue-600 text-white rounded-xl p-6 shadow-xl">
      <h2 className="text-xl font-bold mb-4">Post-Harvesting</h2>
      <p>Short-Term: Profit ₹{gains.stcg.profits}, Loss ₹{gains.stcg.losses}, Net ₹{netST}</p>
      <p>Long-Term: Profit ₹{gains.ltcg.profits}, Loss ₹{gains.ltcg.losses}, Net ₹{netLT}</p>
      <p className="font-semibold mt-2">Realised Capital Gains: ₹{total}</p>
      {savings > 0 && <p className="mt-2 text-green-200">You're going to save ₹{savings}</p>}
    </div>
  );
}