import React from 'react';

export default function PreHarvestCard({ gains }) {
  if (!gains) return null;

  const netST = gains.stcg.profits - gains.stcg.losses;
  const netLT = gains.ltcg.profits - gains.ltcg.losses;
  const total = netST + netLT;

  return (
    <div className="bg-gray-800 text-white rounded-xl p-6 shadow-xl">
      <h2 className="text-xl font-bold mb-4">Pre-Harvesting</h2>
      <p>Short-Term: Profit ₹{gains.stcg.profits}, Loss ₹{gains.stcg.losses}, Net ₹{netST}</p>
      <p>Long-Term: Profit ₹{gains.ltcg.profits}, Loss ₹{gains.ltcg.losses}, Net ₹{netLT}</p>
      <p className="font-semibold mt-2">Realised Capital Gains: ₹{total}</p>
    </div>
  );
}