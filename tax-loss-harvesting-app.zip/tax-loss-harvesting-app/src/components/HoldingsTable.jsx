import React, { useState } from 'react';

export default function HoldingsTable({ holdings, onSelectionChange }) {
  const [selected, setSelected] = useState([]);

  const toggle = (asset) => {
    const exists = selected.includes(asset);
    const newSelection = exists
      ? selected.filter(h => h !== asset)
      : [...selected, asset];
    setSelected(newSelection);
    onSelectionChange(newSelection);
  };

  const toggleAll = () => {
    const newSelection = selected.length === holdings.length ? [] : [...holdings];
    setSelected(newSelection);
    onSelectionChange(newSelection);
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full border border-gray-300">
        <thead>
          <tr className="bg-gray-200">
            <th><input type="checkbox" onChange={toggleAll} checked={selected.length === holdings.length} /></th>
            <th>Asset</th>
            <th>Holdings</th>
            <th>Avg Buy</th>
            <th>Current</th>
            <th>ST Gain</th>
            <th>LT Gain</th>
            <th>Amount to Sell</th>
          </tr>
        </thead>
        <tbody>
          {holdings.map((h, idx) => (
            <tr key={idx} className="text-center">
              <td><input type="checkbox" checked={selected.includes(h)} onChange={() => toggle(h)} /></td>
              <td><img src={h.logo} alt={h.coin} className="inline w-5 h-5 mr-2" />{h.coin}</td>
              <td>{h.totalHoldings}</td>
              <td>{h.averageBuyPrice}</td>
              <td>{h.currentPrice}</td>
              <td>{h.stcg.gain}</td>
              <td>{h.ltcg.gain}</td>
              <td>{selected.includes(h) ? h.totalHoldings : ''}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}